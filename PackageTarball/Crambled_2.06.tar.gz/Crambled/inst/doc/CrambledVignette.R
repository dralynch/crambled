## ----install,eval=FALSE--------------------------------------------------
#  install.packages("devtools")
#  devtools::install_github("dralynch/crambled/Package")

## ----load, warning=FALSE-------------------------------------------------
library("Crambled",warn.conflicts = FALSE, quietly = TRUE)

## ----load other libraries, warning=FALSE---------------------------------
suppressMessages(library("Rsamtools",warn.conflicts = FALSE, quietly = TRUE))
suppressMessages(library("png",warn.conflicts = FALSE, quietly = TRUE))
suppressMessages(library("knitr",warn.conflicts = FALSE, quietly = TRUE))

## ----usage1,eval=FALSE---------------------------------------------------
#  CrambledScan(normal="normal.bam",tumour="tumour.bam",title="TITLE")

## ----usage2,eval=FALSE---------------------------------------------------
#  CrambledScanCellline(normal="CELL_LINE.bam",title="TITLE")

## ----loci,eval=TRUE------------------------------------------------------
CrambledSuggestSNPsHG19()

## ----kable1, echo=FALSE--------------------------------------------------
tmp<-matrix(c(12,15,0,1,0,30,10,3,0,0),byrow=T,ncol=5)
colnames(tmp)<-c("A","C","G","T","N")
rownames(tmp)<-c("Normal","Tumour")  
kable(tmp)

## ----CSI example1--------------------------------------------------------
x<-NULL
tmp<-array(c(12,15,0,1,0,30,10,3,0,0),dim=c(5,2,1))
rownames(tmp)<-c("A","C","G","T","N")
x[["seq"]]<-tmp
CrambledScanInfo(x)

## ----kable2, echo=FALSE--------------------------------------------------
tmp<-matrix(c(1,26,0,1,0,30,10,3,0,0),byrow=T,ncol=5)
colnames(tmp)<-c("A","C","G","T","N")
rownames(tmp)<-c("Normal","Tumour")  
kable(tmp)

## ----CSI example 2-------------------------------------------------------
x<-NULL
tmp<-array(c(1,26,0,1,0,30,10,3,0,0),dim=c(5,2,1))
rownames(tmp)<-c("A","C","G","T","N")
x[["seq"]]<-tmp
CrambledScanInfo(x)

## ----sim-----------------------------------------------------------------
SimCell<-0.62
SimSingleDepth<-30
SimDepths<-NULL
SimAFs<-NULL

numA<-rep(c(0,1,1,2,2,3,2),times=c(500,500,2000,2000,3000,1000,1000))
numB<-rep(c(0,0,1,0,1,0,2),c(500,500,2000,2000,3000,1000,1000))

DepthA<-(1+(numA-1)*SimCell)*SimSingleDepth
DepthB<-(1+(numB-1)*SimCell)*SimSingleDepth

SimA<-rpois(10000,DepthA)
SimB<-rpois(10000,DepthB)

SimDepths<-c(SimA+SimB)
SimAFs<-c(pmin(SimA,SimB)/(SimA+SimB))

SimDepths<-runmed(SimDepths,25)
SimAFs<-runmed(SimAFs,25)

## ----plot, echo=FALSE, fig.width=6, fig.height=4-------------------------
  smoothScatter(SimDepths,SimAFs,transformation = function(x){x^1},main="Simulation",xlab="Depth",ylab="B allele fraction",ylim=c(0,0.5),xlim=c(0,100))
    afclass<-as.numeric(cut(SimAFs,seq(-0.005,0.505,0.01)))
    xbounds<-rep(NA,51)
    for(i in 1:51){
      xbounds[i]<-min(c(SimDepths[afclass==i],100))
    }
    lines(smooth(xbounds),seq(0,0.5,0.01),lwd=2,col="red")      

## ----plotout-------------------------------------------------------------
simplotfile <- tempfile(fileext='.png')
png(simplotfile, width=600,height=400)
  smoothScatter(SimDepths,SimAFs,transformation = function(x){x^1},main="Simulation",xlab="Depth",ylab="B allele fraction",ylim=c(0,0.5),xlim=c(0,100))
    afclass<-as.numeric(cut(SimAFs,seq(-0.005,0.505,0.01)))
    xbounds<-rep(NA,51)
    for(i in 1:51){
      xbounds[i]<-min(c(SimDepths[afclass==i],100))
    }
    lines(smooth(xbounds),seq(0,0.5,0.01),lwd=2,col="red") 
dev.off()

## ----CLloci,eval=FALSE---------------------------------------------------
#  CrambledSuggestSNPsHG19()

## ----CLkable1, echo=FALSE------------------------------------------------
tmp<-matrix(c(30,10,3,0,0),byrow=T,ncol=5)
colnames(tmp)<-c("A","C","G","T","N")
rownames(tmp)<-c("Cellline")  
kable(tmp)

## ----CLCSI example1------------------------------------------------------
x<-NULL
tmp<-array(c(30,10,3,0,0),dim=c(5,1,1))
rownames(tmp)<-c("A","C","G","T","N")
x[["seq"]]<-tmp
CrambledScanInfoCellline(x)

## ----CLsim---------------------------------------------------------------
SimCell<-1
SimSingleDepth<-30
SimDepths<-NULL
SimAFs<-NULL

numA<-rep(c(1,1,2,2,3,2,2,3,4,2,3),times=c(1000,2000,3000,2000,3000,3000,3000,1000,3000,1000,3000))
numB<-rep(c(0,1,0,0,0,1,0,0,0,2,0),times=c(1000,2000,3000,2000,3000,3000,3000,1000,3000,1000,3000))

DepthA<-(1+(numA-1)*SimCell)*SimSingleDepth
DepthB<-(1+(numB-1)*SimCell)*SimSingleDepth

SimA<-rpois(25000,DepthA)
SimB<-rpois(25000,DepthB)

SimDepths<-c(SimA+SimB)
SimAFs<-c(pmin(SimA,SimB)/(SimA+SimB))

## ----CLsimsplit----------------------------------------------------------
    SimDepths1<-runmed(SimDepths[which(SimAFs<0.1)],21)
    SimDepths2<-runmed(SimDepths[which(SimAFs>=0.1)],21)
    SimAFs1<-runmed(SimAFs[which(SimAFs<0.1)],21)
    SimAFs2<-runmed(SimAFs[which(SimAFs>=0.1)],21)

## ----CLsimthin-----------------------------------------------------------
mypoints<-sample(length(SimDepths1),length(SimDepths2))
SimDepths<-c(SimDepths1[mypoints],SimDepths2)
SimAFs<-c(SimAFs1[mypoints],SimAFs2)

## ----CLplot, echo=FALSE, fig.width=6, fig.height=4-----------------------
  smoothScatter(SimDepths,SimAFs,transformation = function(x){x^1},main="Simulation",xlab="Depth",ylab="B allele fraction",ylim=c(0,0.5),xlim=c(0,100))

## ----launchShiny, eval=FALSE---------------------------------------------
#  RunCrambledShinyApp()

## ------------------------------------------------------------------------

    mycell<-0.62
    mydepth<-30
    
    Dmat<-matrix(ncol=8,nrow=8,NA)
    Amat<-matrix(ncol=8,nrow=8,NA)
    Bmat<-matrix(ncol=8,nrow=8,NA)
    
    for(i in 1:5){
      for(j in i:5){
        Dmat[i,j]<-2*mydepth*(1-mycell)+mycell*(i+j-2)*mydepth
        Amat[i,j]<-(1-mycell+mycell*(i-1))/( 2*(1-mycell)+(i+j-2)*mycell) 
              
        mydens<-dbinom(0:round(Dmat[i,j]),round(Dmat[i,j]),Amat[i,j])
        myval<-(0:round(Dmat[i,j]))/round(Dmat[i,j])
        myval[myval>0.5]<-1-myval[myval>0.5]
        
        Bmat[i,j]<-sum(myval*mydens)
        
      }  
    }
    
    ABlabels<-c("0",rep("",7),"A","AB",rep("",6),"AA","AAB","AABB",rep("",5),"AAA","AAAB","AAABB","AAABBB",rep("",4),"AAAA","AAAAB","AAAABB","AAAABBB","AAAABBBB")

## ------------------------------------------------------------------------
    predfile <- tempfile(fileext='.png')
    png(predfile, width=600, height=400)
    plot(1,1,type="n",ylim=c(0,0.5),xlim=c(0,100),axes=F,xlab="",ylab="",main="")
    points(Dmat,Bmat,pch=21,col="black",bg="yellow")
    text(as.vector(Dmat)[1:37],as.vector(Bmat)[1:37],ABlabels,col="red",cex=0.75,pos=1)
dev.off()   

## ----image1,fig.width=6, fig.height=4------------------------------------
underpng<-png::readPNG(simplotfile)
par(mar=c(0,0,0,0))
plot(1,1,type="n",ylim=c(0,0.5),xlim=c(0,100),axes=F,xlab="",ylab="",main="")
rasterImage(underpng,0,0,100,0.5)

## ----image2,fig.width=6, fig.height=4------------------------------------
overpng<-png::readPNG(predfile)
par(mar=c(0,0,0,0))
plot(1,1,type="n",ylim=c(0,0.5),xlim=c(0,100),axes=F,xlab="",ylab="",main="")
rasterImage(overpng,0,0,100,0.5)

## ----image3,fig.width=6, fig.height=4------------------------------------
matte<-(overpng[,,1]+overpng[,,2]+overpng[,,3])<3
for(i in 1:3){
  tmpu<-underpng[,,i]
  tmpo<-overpng[,,i]
  tmpu[matte]<-tmpo[matte]
  underpng[,,i]<-tmpu
}
par(mar=c(0,0,0,0))
plot(1,1,type="n",ylim=c(0,0.5),xlim=c(0,100),axes=F,xlab="",ylab="",main="")
rasterImage(underpng,0,0,100,0.5)

